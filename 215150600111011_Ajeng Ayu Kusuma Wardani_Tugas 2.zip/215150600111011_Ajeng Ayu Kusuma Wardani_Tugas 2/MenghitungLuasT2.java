/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package menghitungluast2;
import java.io.*;
import java.util.*;
/**
 *
 * @author ajeng
 */
class Persegi{
    
    void Luaspersegi(int sisi){
    System.out.println(sisi*sisi);
    }
    }

    class Segitiga{
    void Luassegitiga(int alas, int tinggi){
    
    System.out.println(alas*tinggi/2);
    }
    }
    class Lingkaran{
     
    void Luaslingkaran(double r){
        
            if(r%7 ==0){
                double jwb = 22/7 *(r*r);
                System.out.println(jwb);
            } else {
                double jwb = 3.14*(r*r);
                int result = (int)jwb;
                System.out.println((double)result);
  
            }
        }
    }

public class MenghitungLuasT2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
        int pilihan = input.nextInt();
        if (pilihan == 1){
            int sisi= input.nextInt();
            Persegi Luaspersegi = new Persegi();
            Luaspersegi.Luaspersegi(sisi);
        }
        else if (pilihan == 2){
            int alas = input.nextInt();
            int tinggi = input.nextInt();
            Segitiga Luassegitiga = new Segitiga();
            Luassegitiga.Luassegitiga(alas, tinggi);
        }
        else if (pilihan== 3){
            int r = input.nextInt();
            Lingkaran Luaslingkaran = new Lingkaran();
            Luaslingkaran.Luaslingkaran(r);
        }
        else System.out.println("Input yang anda masukan tidak sesuai");
    }
}

