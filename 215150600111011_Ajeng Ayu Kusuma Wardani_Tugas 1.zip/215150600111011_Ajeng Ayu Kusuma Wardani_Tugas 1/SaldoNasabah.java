/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package saldonasabah;
import java.io.*;
import java.util.*;
/**
 *
 * @author ajeng
 */
public class SaldoNasabah {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double sld = input.nextInt();
        double str = input.nextInt();
        Mesin(sld, str);
    }
    public static void Mesin(double sld, double str){
        double ba = 7000;
        double jmlh = (sld + str);
        jmlh -= ba;
        double potong = jmlh * 0.0005;
        System.out.print(jmlh + potong);
    }
}
